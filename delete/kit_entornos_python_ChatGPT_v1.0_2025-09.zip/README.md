# Kit de Entornos Python (Windows / CMD)

Este kit contiene todo lo necesario para **gestionar entornos virtuales en Windows con CMD**.

## 📂 Contenido

### Notebooks
- `notebooks/Entorno_virtual_VSCode_CMD_v6.ipynb` → Notebook principal con la guía de entornos en CMD + anexo de scripts.
- `notebooks/Guia_scripts_CMD_entornos.ipynb` → Guía independiente solo para los 4 scripts .cmd.

### Scripts CMD
- `scripts/setup_venv_from_requirements.cmd` → Crea/actualiza `.venv` desde `requirements.txt`. (No deja el entorno activo.)
- `scripts/reset_venv_from_requirements.cmd` → Borra y recrea `.venv` desde cero con confirmación. (Deja el entorno activo.)
- `scripts/provision_and_open_venv.cmd` → Crea/actualiza `.venv` y deja la ventana abierta con el entorno activo.
- `scripts/open_venv_here.cmd` → Abre una CMD con `.venv` activado (no crea ni instala nada).

### Documentación
- `docs/Guia_completa_scripts_CMD_entornos.md` → Guía extensa con usos, pasos y solución de problemas.
- `docs/Chuleta_scripts_CMD_entornos_VERTICAL.pdf` → Chuleta rápida (versión oficial) en una sola página, formato vertical.
- `docs/requirements_example.txt` → Ejemplo de `requirements.txt` para practicar.

## ✅ Recomendación
- Lee primero el **notebook principal** para entender el flujo de trabajo con entornos.
- Usa la **chuleta PDF** como referencia rápida.
- Los **scripts CMD** son reutilizables en cualquier proyecto: cópialos en la carpeta raíz y ejecútalos según necesites.

## 🧪 Comandos básicos de verificación

Después de usar cualquier script, confirma que todo esté correcto ejecutando en CMD (con el entorno activo):

```cmd
python --version
```

Muestra la versión de Python que está usando el entorno.

```cmd
where python
```

La primera ruta debe apuntar a `.venv\Scripts\python.exe`.

```cmd
pip list
```

Muestra todas las dependencias instaladas en el entorno.

En un notebook, también puedes verificar con:

```python
import sys
print(sys.executable)
```

Debería mostrar la ruta hacia `.venv\Scripts\python.exe`.

---
© Kit generado para ayudarte a manejar entornos virtuales en Python fácilmente 🚀
