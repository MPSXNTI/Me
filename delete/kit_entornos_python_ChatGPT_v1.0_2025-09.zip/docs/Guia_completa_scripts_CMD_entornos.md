
# Guía completa de los scripts `.cmd` para gestionar entornos virtuales (Windows, CMD)

Esta guía te explica **qué hace cada script**, **cuándo usarlo**, **cómo ejecutarlo**, **qué deberías ver** y **cómo resolver errores típicos**.
Está pensada para quien **no tiene experiencia previa** con entornos virtuales o con CMD.

> **Requisitos previos (importante):**
> - Tener instalado **Python 3.x** en Windows.
> - Python debe estar en el **PATH** (de modo que `python --version` funcione en CMD).
> - Tu proyecto debe estar en una carpeta, p. ej. `C:\Users\TU\Desktop\mi_proyecto`.
> - (Opcional) Un archivo `requirements.txt` en la raíz del proyecto con tus dependencias.
> - **Usaremos CMD (Símbolo del sistema)**, no PowerShell.

---

## 📂 Dónde colocar los scripts

Copia los 4 archivos `.cmd` en la **raíz del proyecto**, es decir, en la misma carpeta donde estará tu carpeta `.venv` y tu `requirements.txt` (si lo usas).

Ejemplo de estructura:
```
mi_proyecto/
 ├─ .venv/                 (carpeta del entorno virtual; puede no existir aún)
 ├─ requirements.txt       (opcional pero recomendado)
 ├─ setup_venv_from_requirements.cmd
 ├─ reset_venv_from_requirements.cmd
 ├─ provision_and_open_venv.cmd
 └─ open_venv_here.cmd
```

---

## 🧠 Conceptos rápidos (para situarte)

- **Entorno virtual (`.venv`)**: una “carpeta aislada” donde se instalan las librerías de **ese proyecto** sin afectar a todo el sistema.
- **Activar el entorno**: hace que los comandos `python` y `pip` usen el Python de `.venv` y no el del sistema.
- **`requirements.txt`**: lista de dependencias que tu proyecto necesita.
- **CMD vs PowerShell**: aquí **usaremos CMD**. Si se abre PowerShell por defecto en VS Code, cambia el perfil a **Command Prompt (cmd)**.

---

# 1) `setup_venv_from_requirements.cmd` — **Provisionar** (crear/actualizar) el entorno desde `requirements.txt`

### ¿Qué hace?
- Si **no existe** `.venv`, lo **crea**.
- **Activa temporalmente** el entorno **dentro del script**.
- **Actualiza `pip`**.
- Si encuentra `requirements.txt`, **instala** todas las dependencias listadas.
- Muestra la **versión de Python, la ruta** y el **listado de paquetes**.
- **No deja** el entorno activado cuando termina (cierra su sesión).

### ¿Cuándo usarlo?
- Primera vez que montas el proyecto en esta PC.
- Cuando alguien te pasó `requirements.txt` y necesitas instalar rápido todo.
- Cuando actualizaste `requirements.txt` y quieres **refrescar dependencias**.

### ¿Cómo usarlo?
1. Abre **CMD** en la carpeta del proyecto:  
   `cd C:\Users\TU\Desktop\mi_proyecto`
2. Ejecuta:  
   `setup_venv_from_requirements.cmd`
3. Al terminar, **activa el entorno para trabajar**:  
   `.venv\Scripts\activate.bat`

### ¿Qué debería ver?
- Mensajes tipo: “Creando entorno…”, “Actualizando pip…”, “Instalando dependencias…”.  
- Al final, salidas de `python --version`, `where python` y `pip list`.

### Errores típicos y soluciones
- **`'python' no se reconoce`** → Python no está en PATH. Reinstala Python marcando “Add python to PATH” o abre un CMD nuevo.
- **No hay `requirements.txt`** → El script seguirá pero mostrará aviso. Puedes crearlo con `pip freeze > requirements.txt` desde el entorno correcto.
- **Cortafuegos/Antivirus bloquea** → Permite Python temporalmente.
- **Rutas con espacios** → No hay problema si ejecutas desde la carpeta correcta (el script usa rutas relativas).

---

# 2) `reset_venv_from_requirements.cmd` — **Borrar y recrear** el entorno desde cero (con confirmación)

### ¿Qué hace?
- Te pregunta: “¿Quieres borrar y recrear el entorno .venv? (S/N)”.
- Si dices **S**:
  - **Elimina** la carpeta `.venv`.
  - **Crea** un **.venv nuevo**.
  - **Activa el entorno**, **actualiza pip** e **instala** dependencias desde `requirements.txt` si existe.
  - Deja **abierta** la ventana CMD con el entorno activo (lista para usar).
- Si dices **N**, cancela sin cambios.

### ¿Cuándo usarlo?
- Cuando tu entorno “se rompió” o tienes conflictos de versiones.
- Cuando quieres **empezar fresco** (clean slate) sin restos.
- Cuando cambiaste de versión de Python y quieres regenerar el entorno.

### ¿Cómo usarlo?
1. Abre CMD en la carpeta del proyecto.
2. Ejecuta: `reset_venv_from_requirements.cmd`
3. Responde **S** si estás seguro.
4. Se quedará **listo y activado** al terminar.

### ¿Qué debería ver?
- Mensajes de borrado/creación e instalación.
- Prompt con prefijo `(.venv)` al final.

### Errores típicos
- **`El proceso no puede acceder al archivo`** (archivos “en uso”):
  - Cierra VS Code y cualquier terminal que esté usando `.venv` y vuelve a intentar.
- **No hay `requirements.txt`**:
  - No pasa nada, el entorno queda vacío. Instala luego con `pip install ...` y después crea `requirements.txt`.
- **Permisos**:
  - Ejecuta CMD como **Administrador** si obtienes errores de acceso al borrar carpetas.

---

# 3) `provision_and_open_venv.cmd` — Provisionar **y** dejar la ventana abierta con `.venv` activo

### ¿Qué hace?
- Si **no existe** `.venv`, lo **crea**.
- **Activa** `.venv`.
- **Actualiza `pip`**.
- Si hay `requirements.txt`, **instala** los paquetes.
- **Deja la terminal abierta** con el entorno activado (ideal para empezar a trabajar ya).

### ¿Cuándo usarlo?
- Cuando quieres un **todo-en-uno**: provisionar (si hace falta) y **quedarte dentro del entorno** para trabajar sin pasos extras.

### ¿Cómo usarlo?
1. CMD en la carpeta del proyecto.
2. Ejecuta: `provision_and_open_venv.cmd`
3. Al terminar, verás `(.venv)` y podrás correr tus comandos.

### Errores típicos
- Iguales a los de `setup_venv_from_requirements.cmd`.
- Si `requirements.txt` falta, simplemente avisa y deja el entorno activo (puedes instalar manualmente).

---

# 4) `open_venv_here.cmd` — Abrir una CMD **ya activada** en `.venv`

### ¿Qué hace?
- **No crea** ni instala nada.
- Abre una ventana CMD **con el entorno `.venv` activado** (si `.venv` existe).

### ¿Cuándo usarlo?
- Cuando **ya tienes** el entorno creado y solo quieres **empezar a trabajar ya** sin recordar el comando de activación.
- Es el **atajo más rápido** para “abrir el entorno”.

### ¿Cómo usarlo?
- Doble clic sobre `open_venv_here.cmd`
- O desde CMD: `open_venv_here.cmd`

### ¿Qué debería ver?
- Una terminal nueva con el prompt:
  ```
  (.venv) C:\Users\TU\Desktop\mi_proyecto>
  ```

### Errores típicos
- **`No existe el entorno .venv en este directorio`**:
  - Primero ejecuta `setup_venv_from_requirements.cmd` o `provision_and_open_venv.cmd` para crearlo; o créalo manualmente:  
    `python -m venv .venv`

---

## ✅ Checklist rápido (para saber que todo está bien)

1. En la terminal, **ves `(.venv)`** al inicio de la línea.
2. `where python` muestra primero la ruta dentro de `.venv\Scripts\python.exe`.
3. `pip list` muestra tus paquetes esperados.
4. En VS Code, la barra de estado dice algo como:  
   `Python 3.x ('.venv': venv)`  
   y el **Kernel** del notebook usa tu `.venv`.

---

## 🧯 Solución de problemas (FAQ)

**Q1. Ejecuté un script y no pasó nada, o la ventana se cerró muy rápido.**  
- Ejecuta el `.cmd` desde una **ventana de CMD abierta** en la carpeta del proyecto para ver los mensajes.  
- Verifica permisos del sistema/antivirus.

**Q2. `python` no se reconoce.**  
- Reinstala Python marcando “Add Python to PATH”. Abre **una nueva** ventana de CMD.

**Q3. VS Code usa otro Python y no mi `.venv`.**  
- `Ctrl+Shift+P` → *Python: Select Interpreter* → elige `.<tu_venv>\Scripts\python.exe`.  
- Reinicia el **Language Server** o la ventana (`Developer: Reload Window`).

**Q4. Error al borrar `.venv` en `reset_venv_from_requirements.cmd`.**  
- Cierra todas las terminales/VS Code que lo usen. Si persiste, reinicia Windows o borra manualmente la carpeta cuando no esté en uso.

**Q5. `requirements.txt` no existe o tiene demasiadas cosas.**  
- Puedes generarlo con `pip freeze > requirements.txt`.
- O escribirlo a mano con sólo lo necesario (ej.: `flask==3.0.3`).

**Q6. ¿Puedo usar estos scripts si el proyecto está en otra ruta o con espacios?**  
- Sí. Los scripts trabajan desde su **directorio actual**. Abre CMD en la carpeta del proyecto o haz doble clic desde ahí.

**Q7. ¿Y si quiero borrar y recrear con otra versión de Python?**  
- Instala/selecciona la versión que quieras como `python` por defecto en PATH. El script usará ese `python` para crear el `.venv` nuevo.

---

## 🧪 Comandos de verificación útiles (después de usar cualquier script)

En **CMD** (con `.venv` activo, excepto donde se diga lo contrario):

```cmd
python --version
where python
pip list
```

En un **notebook** (`.ipynb`) dentro de VS Code, ejecuta:
```python
import sys
sys.executable
```

Deberías ver la ruta hacia `...\.venv\Scripts\python.exe`.

---

## 📌 Recomendaciones finales

- Un **entorno por proyecto**.
- Guarda y versiona tu `requirements.txt`.
- Si algo se rompe, usa el **reset** con confirmación y reinstala desde `requirements.txt`.
- En VS Code, **selecciona el intérprete** correcto y, si hace falta, **reinicia el analizador** y la **terminal integrada**.

---

### ¡Listo!
Con estos 4 scripts puedes crear, resetear, provisionar y abrir entornos rápidamente, incluso si no recuerdas los comandos manuales.
