from .calc import DISPATCH

def parse_float(prompt: str) -> float:
    # TODO: validar/repreguntar hasta recibir un float válido
    raise NotImplementedError

def main() -> None:
    # TODO: leer a, b, operador; usar DISPATCH; imprimir resultado redondeado
    raise NotImplementedError

if __name__ == "__main__":
    main()