# Analizador de texto (archivo)

**Descripción rápida:** Métricas y top palabras desde archivo .txt.

## Cómo ejecutar
```bash
python main.py
```

## Siguientes pasos (Nivel Plus)
- Añade logs/errores más claros
- Escribe pruebas unitarias mínimas
- Documenta funciones con docstrings