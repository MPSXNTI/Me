# Gestor de tareas (To-Do)

**Descripción rápida:** CRUD de tareas persistido en JSON.

## Cómo ejecutar
```bash
python main.py
```

## Siguientes pasos (Nivel Plus)
- Añade logs/errores más claros
- Escribe pruebas unitarias mínimas
- Documenta funciones con docstrings