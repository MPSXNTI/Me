# Conversor de unidades

**Descripción rápida:** Conversor C↔F con interfaz de consola y validaciones.

## Cómo ejecutar
```bash
python main.py
```

## Siguientes pasos (Nivel Plus)
- Añade logs/errores más claros
- Escribe pruebas unitarias mínimas
- Documenta funciones con docstrings