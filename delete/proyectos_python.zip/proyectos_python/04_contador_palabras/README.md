# Contador de palabras

**Descripción rápida:** Tokeniza texto y calcula top de palabras.

## Cómo ejecutar
```bash
python main.py
```

## Siguientes pasos (Nivel Plus)
- Añade logs/errores más claros
- Escribe pruebas unitarias mínimas
- Documenta funciones con docstrings